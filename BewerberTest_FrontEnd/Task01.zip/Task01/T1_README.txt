﻿Bei Aufgabe 1 soll folgende Anwendung realisiert werden.

Auf einer Webseite (index.html) sollen 2 Buttons verfügbar sein.
Die Buttons 
senden jeweils einen Request an ein PHP Skript.
Im PHP Skript soll der Request verarbeitet werden und ein User in einer
MySQL Datenbank 
gesucht werden.
Wenn der User gefunden wurde, dann sollen alle Daten des Users zurück gesendet werden.
Wenn der User nicht gefunden wurde, 
soll eine Fehlermeldung ausgegeben werden.
